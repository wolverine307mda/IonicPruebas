import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-7COD3VIK.js";
import "./chunk-MPRFTPEU.js";
import "./chunk-PAKANIVX.js";
export default require_cjs();
