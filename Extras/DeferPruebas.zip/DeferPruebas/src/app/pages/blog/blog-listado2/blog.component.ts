import { Location, CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { ApiService } from '../../../api/api-service';
import BlogModel from '../../../models/blog/blog.model';
import PagingModel from '../../../models/general/paging.model';
import { SeoService } from '../../../services/seo.service';
import { UtilService } from '../../../services/util.service';
import { CajaBlogListadoComponent2 } from '../../../components/caja-blog-listado2/caja-blog-listado.component';

@Component({
  selector: 'app-blog',
  standalone: true,
  imports: [CommonModule, NgxPaginationModule, CajaBlogListadoComponent2],
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.scss']
})
export class BlogComponent2 implements OnInit {

  public blogs: BlogModel[];
  public loading: boolean = true;
  public mostrarLoader: boolean = true;
  public start: number;
  public limit: number;
  public total: number = 0;
  public page: number;
  public pageSize: number;
  public paginationModel: PagingModel<BlogModel> = new PagingModel([], 0, 0);
  public urlES: String;
  public urlEN: String;

  constructor(
    public api: ApiService,
    public utilsService: UtilService,
    private seo: SeoService,
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
  ) {
    this.blogs = [];
    this.start = 0;
    this.limit = 12; // Cambiado de 0 a 12
    this.pageSize = 12;
    // this.page = 1;

    const pageParam = this.route.snapshot.queryParamMap.get('page');
    this.page = pageParam !== null ? parseInt(pageParam, 10) : 1;
    
    // Calcular el start basado en la página actual
    this.start = (this.page - 1) * this.pageSize;

      if (this.page > 1) {
        this.seo.updateCanonicalURL(`${this.api.urlSEO}/blog?page=${this.page}`);
        this.seo.updateOgUrlFacebook(`${this.api.urlSEO}/blog?page=${this.page}`);
        this.seo.updateTwitterURL_Site(`${this.api.urlSEO}/blog?page=${this.page}`);
      } else {
        this.seo.updateCanonicalURL(`${this.api.urlSEO}/blog`);
        this.seo.updateOgUrlFacebook(`${this.api.urlSEO}/blog`);
        this.seo.updateTwitterURL_Site(`${this.api.urlSEO}/blog`);
      }
    
      this.urlES = `${this.api.urlSEO}/blog?page=${this.page}`
      this.urlEN = `${this.api.urlSEO}/en/blog?page=${this.page}`
      this.seo.updateAlternateEsURL(`${this.api.urlSEO}/blog?page=${this.page}`);
      this.seo.updateAlternateEnURL(`${this.api.urlSEO}/en/blog?page=${this.page}`);




    //Facebook
    this.seo.updateOgImageFacebook("https://www.sumainmobiliaria.es/assets/images/logo.svg", 270, 70)
    //Twitter
    this.seo.updateTwitterImage("https://www.sumainmobiliaria.es/assets/images/logo.svg")


      this.seo.updateTitle("Consejos para la compra venta de inmuebles en Madrid | Blog SUMA Inmobiliaria");
      this.seo.updateTitleTwitter("Consejos para la compra venta de inmuebles en Madrid | Blog SUMA Inmobiliaria");
      this.seo.updateOgTitleFacebook("Consejos para la compra venta de inmuebles en Madrid | Blog SUMA Inmobiliaria");
      this.seo.updateDescription("Si quieres vender, alquilar o comprar tu casa de lujo en Madrid, aquí te daremos cientos de consejos y orientación profesional.");
      this.seo.updateDescriptionTwitter("Si quieres vender, alquilar o comprar tu casa de lujo en Madrid, aquí te daremos cientos de consejos y orientación profesional.");
      this.seo.updateOgDescriptionFacebook("Si quieres vender, alquilar o comprar tu casa de lujo en Madrid, aquí te daremos cientos de consejos y orientación profesional.");
    


  }

  async ngOnInit(): Promise<void> {
    this.scrollToTop();
    this.init();
  }

  async init() {
    try {
      await this.getDataBlogs();
    } catch (error) {
      console.error("Error al cargar los blogs:", error);
    }

  }


  async getDataBlogs() {
    this.paginationModel = await this.api.Blogs.getBlogsWithPagination(this.start, this.limit);
    this.blogs = this.paginationModel.collection;
    this.total = this.paginationModel.total;
    this.loading = false;
    return;
  }

  async eventoPaginadoListado(pageSize: number, event: any) {

    try {
      this.loading = true;
      this.start = (event - 1) * pageSize;
      this.limit = pageSize;
      await this.getDataBlogs();
      this.page = event;


      const currentUrl = this.location.path();

      // Actualiza o agrega el parámetro `page` en la query string

      if (this.page === 1) {
        // Elimina el parámetro ?page= seguido de un número
        const urlSinPage = currentUrl.replace(/(\?|&)page=\d+/, '');

        // Corrige el formato si el parámetro eliminado era el primero
        const finalUrl = urlSinPage.startsWith('&') ? urlSinPage.replace('&', '?') : urlSinPage;

        // Usa el servicio Location para cambiar la URL sin recargar la página
        this.location.go(finalUrl);
      } else {
        const updateUrl = this.updateQueryStringParameter(currentUrl, 'page', this.page);
        this.location.go(updateUrl);
      }

      //1- Updateamos el canonical y los hreflang para la nueva paginación

      if (this.page === 1) {

        this.urlES = `${this.api.urlSEO}/blog`
        this.urlEN = `${this.api.urlSEO}/en/blog`

        this.seo.updateAlternateEsURL(`${this.urlES}`);
        this.seo.updateAlternateEnURL(`${this.urlEN}`);


        if (this.router.url.includes('/en/')) {
          this.seo.updateCanonicalURL(`${this.urlEN}`);
          this.seo.updateOgUrlFacebook(`${this.urlEN}`);

          this.seo.updateTwitterURL_Site(`${this.urlEN}`);
        } else {
          this.seo.updateCanonicalURL(`${this.urlES}`);
          this.seo.updateOgUrlFacebook(`${this.urlES}`);
          this.seo.updateTwitterURL_Site(`${this.urlES}`);
        }


      } else {

        this.urlES = `${this.api.urlSEO}/blog?page=${this.page}`
        this.urlEN = `${this.api.urlSEO}/en/blog?page=${this.page}`

        if (this.router.url.includes('/en/')) {
          this.seo.updateCanonicalURL(`${this.urlEN}`);
          this.seo.updateOgUrlFacebook(`${this.urlEN}`);
          this.seo.updateTwitterURL_Site(`${this.urlEN}`);
        } else {
          this.seo.updateCanonicalURL(`${this.urlES}`);
          this.seo.updateOgUrlFacebook(`${this.urlES}`);
          this.seo.updateTwitterURL_Site(`${this.urlES}`);
        }

        this.seo.updateAlternateEsURL(`${this.urlES}`);
        this.seo.updateAlternateEnURL(`${this.urlEN}`);

      }

      this.scrollToTop();
    } catch (error: any) {
    }
  }

  private updateQueryStringParameter(uri: string, key: string, value: any): string {
    const re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    const separator = uri.indexOf('?') !== -1 ? "&" : "?";
    if (uri.match(re)) {
      return uri.replace(re, '$1' + key + "=" + value + '$2');
    } else {
      return uri + separator + key + "=" + value;
    }
  }

  public scrollToTop() {
    if (typeof window !== 'undefined') {
      window.scrollTo(0, 0); 
    }
  }
}