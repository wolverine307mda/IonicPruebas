import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BlogComponent2 } from './blog.component';
import { FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { BlogRoutingModule } from './blog-routing.module';
import { SharedModule } from 'primeng/api';


@NgModule({
  declarations: [
  ],
  imports: [
    BlogComponent2,
    SharedModule,
    CommonModule,
    FormsModule,
    NgxPaginationModule,
    BlogRoutingModule
  ]
})
export class BlogModule { }
