import { Location, CommonModule } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import BlogModel from '../../../models/blog/blog.model';
import { ApiService } from '../../../api/api-service';
import { SeoService } from '../../../services/seo.service';
import { UtilService } from '../../../services/util.service';
import { CajaBlogListadoComponent } from '../../../components/caja-blog-listado/caja-blog-listado.component';
import { SkeletonModule } from 'primeng/skeleton';
import { SkeletonListBlog } from "../../../components/skeleton-list-blog/skeleton-list-blog";
import { Busqueda } from "../../../components/busqueda/busqueda";
import { TranslateModule } from '@ngx-translate/core';


@Component({
  selector: 'app-blog',
  standalone: true,
  imports: [CommonModule, RouterModule, CajaBlogListadoComponent, NgxPaginationModule, SkeletonModule, SkeletonListBlog, Busqueda, TranslateModule],
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.scss']
})
export class BlogComponent implements OnInit {

  skeletons: number[] = [];

  public blogs: BlogModel[] = [];
  public start: number = 0;
  public limit: number = 12;
  public cargandoMas: boolean = false;
  public finDePagina: boolean = false;
  public total: number = 0;
  public pageSize: number = 6; 
  public languageService = { language: 'es' }; 
  public filtro_Busqueda: string = '';

  constructor(
    public api: ApiService,
    private seo: SeoService,
    private location: Location,
    public utilsService: UtilService,
  ) {
    // SEO configuration
    this.seo.updateCanonicalURL(`${this.api.urlSEO}/blog`);
    this.seo.updateOgUrlFacebook(`${this.api.urlSEO}/blog`);
    this.seo.updateTwitterURL_Site(`${this.api.urlSEO}/blog`);

    //Facebook
    this.seo.updateOgImageFacebook("https://www.sumainmobiliaria.es/assets/images/logo.svg", 270, 70)
    //Twitter
    this.seo.updateTwitterImage("https://www.sumainmobiliaria.es/assets/images/logo.svg")
  }

  ngOnInit(): void {
    this.skeletons = Array(this.pageSize).fill(0);
    this.scrollToTop();
    this.start = 0;
    this.blogs = [];
    this.cargandoMas = false;
    this.finDePagina = false;
  }

  async getDataBlogs() {
    try {
      const result = await this.api.Blogs.getBlogsFiltrado(this.start, this.limit , this.filtro_Busqueda);
      
      if (result && Array.isArray(result)) {
        console.log('Resultados obtenidos:', result.length, 'blogs');
        if (this.start === 0) {
          this.blogs = result;
        } else {
          this.blogs.push(...result);
        }
                
        if (result.length < this.limit) {
          this.finDePagina = true;
        }
        
        return result;
      } else {
        console.log('No se recibieron datos válidos de la API');
        return [];
      }
    } catch (error) {
      console.error('Error al cargar blogs:', error);
      if (this.start === 0) {
        this.blogs = [];
      }
      return [];
    }
  }

  public scrollToTop() {
    if (typeof window !== 'undefined') {
      window.scrollTo(0, 0);
    }
  }

  async ScrollPaginacionInfinita() {
    if (this.cargandoMas || this.finDePagina) return;
    this.cargandoMas = true;

    this.start += this.limit;
    
    await this.getDataBlogs();
    
    this.cargandoMas = false;
  }

  onBuscar(valor: string) {
    console.log('onBuscar ejecutado con valor:', valor);
    this.start = 0;
    this.filtro_Busqueda = valor;
    this.finDePagina = false;
    this.blogs = [];
    this.getDataBlogs();
  }

  @HostListener('window:scroll', [])
  onScroll(): void {
    const bottomReached = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 10;
    if (bottomReached) {
      this.ScrollPaginacionInfinita();
    }
  }

  iniciarCargaDatos(): string {
    if (this.blogs.length === 0 && !this.cargandoMas) {
      this.start = -12;
      setTimeout(() => this.ScrollPaginacionInfinita(), 0);
    }
    return '';
  }
}