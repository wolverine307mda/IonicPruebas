import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetalleBlogComponent } from './detalle-blog.component';

const routes: Routes = [{ path: '', component: DetalleBlogComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DetalleBlogRoutingModule { }
