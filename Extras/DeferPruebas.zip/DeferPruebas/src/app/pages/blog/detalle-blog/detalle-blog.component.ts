import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../api/api-service';
import BlogModel from '../../../models/blog/blog.model';
import { SeoService } from '../../../services/seo.service';

@Component({
  selector: 'app-detalle-blog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detalle-blog.component.html',
  styleUrls: ['./detalle-blog.component.scss'],
})
export class DetalleBlogComponent implements OnInit {

  public loading: boolean = true;
  public blog: BlogModel;
  ultimasEntradas: BlogModel[] = [];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private api: ApiService,
    private seo: SeoService
  ) {
    this.blog = this.route.snapshot.data['data'];

    // SEO Configuration
    this.seo.updateCanonicalURL(`${this.api.urlSEO}/blog/${this.blog.slugURLES.replace('ñ', 'n')}`);
    this.seo.updateOgUrlFacebook(`${this.api.urlSEO}/blog/${this.blog.slugURLES.replace('ñ', 'n')}`);
    this.seo.updateTwitterURL_Site(`${this.api.urlSEO}/blog/${this.blog.slugURLES.replace('ñ', 'n')}`);

    //Facebook
    this.seo.updateOgImageFacebook(this.blog.imagenCabecera, 270, 70)
    //Twitter
    this.seo.updateTwitterImage(this.blog.imagenCabecera)

    this.seo.updateTitle(this.blog.titulo);
    this.seo.updateTitleTwitter(this.blog.titulo);
    this.seo.updateOgTitleFacebook(this.blog.titulo);
    this.seo.updateDescription("");
    this.seo.updateDescriptionTwitter("");
    this.seo.updateOgDescriptionFacebook("");
  }


  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      window.scrollTo(0, 0); // Volvemos a posicionar el scroll de la página arriba del todo
    }
    this.loading = false;
  }

  compartirURL(tipoModo: number) {
    const blogUrl = `${this.api.urlSEO}/blog/${this.blog.slugURLES.replace("ñ", "n")}`;

    switch (tipoModo) {
      case 1: //Facebook
        if (typeof window !== 'undefined') {
          window.open(`https://www.facebook.com/sharer/sharer.php?u=${blogUrl}`, '_blank', '');
        }
        break;

      case 2: //Twitter
        if (typeof window !== 'undefined') {
          window.open(`https://twitter.com/intent/tweet?text=${blogUrl}`, '_blank', '');
        }
        break;

      case 3: //LinkedIn
        if (typeof window !== 'undefined') {
          window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${blogUrl}`, '_blank', '');
        }
        break;
      case 4: //Whatsapp
        if (typeof window !== 'undefined') {
          window.open(`https://api.whatsapp.com/send?text=${blogUrl}`, '_blank', '');
        }
        break;
      case 5: //Email
        if (typeof window !== 'undefined') {
          window.open(`mailto:info@sumainmobiliaria.es`, '_blank', '');
        }
        break;
    }
  }

}



