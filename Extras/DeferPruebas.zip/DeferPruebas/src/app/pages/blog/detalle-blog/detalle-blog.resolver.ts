import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, ResolveData, Router } from "@angular/router";
import { ApiService } from "../../../api/api-service";
import BlogModel from "../../../models/blog/blog.model";

@Injectable({
    providedIn: 'root'
})
export class DetalleBlogResolver implements ResolveData {
    constructor(
        public api: ApiService,
        private router: Router
    ) { }

    public async resolve(route: ActivatedRouteSnapshot): Promise<BlogModel> {
        try {
             let _titulo = route.paramMap.get('titulo')
             if (_titulo) {
               let titulo: string = _titulo
               if (titulo != null && titulo != undefined && titulo.trim().length > 0) {
                 return await this.api.Blogs.getByTitulo(titulo);
               } else {
                this.router.navigate(['/404'])
                 return new BlogModel()
               }
             } else {
              this.router.navigate(['/404'])
               return new BlogModel()
             }

        } catch (ex: any) {
            this.router.navigate(['/404'])
            throw ex
        }
    }
}

