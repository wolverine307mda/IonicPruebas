import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetalleBlogRoutingModule } from './detalle-blog-routing.module';
import { DetalleBlogComponent } from './detalle-blog.component';

@NgModule({
  imports: [
    CommonModule,
    DetalleBlogRoutingModule,
    DetalleBlogComponent
  ]
})
export class DetalleBlogModule { }
