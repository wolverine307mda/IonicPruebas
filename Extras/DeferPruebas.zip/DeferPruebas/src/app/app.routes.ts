import { Routes } from '@angular/router';
import { DetalleBlogResolver } from './pages/blog/detalle-blog/detalle-blog.resolver';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/blog',
    pathMatch: 'full'
  },
  {
    path: 'blog',
    loadChildren: () => import('./pages/blog/blog-listado/blog.module').then(m => m.BlogModule)
  },
  {
    path: 'blog2',
    loadComponent: () => import('./pages/blog/blog-listado2/blog.component').then(m => m.BlogComponent2)
  },
  {
    path: 'blog/:titulo',
    loadChildren: () => import('./pages/blog/detalle-blog/detalle-blog.module').then(m => m.DetalleBlogModule),
    resolve: {
      data: DetalleBlogResolver
    }
  },
  {
    path: 'blogs',
    redirectTo: '/blog',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/blog'
  }
];
