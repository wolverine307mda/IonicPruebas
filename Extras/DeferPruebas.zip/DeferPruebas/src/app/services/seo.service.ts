import { Injectable, Inject, Renderer2, RendererFactory2, PLATFORM_ID, SecurityContext } from '@angular/core';
import { Title, Meta, DomSanitizer } from '@angular/platform-browser';
import { DOCUMENT, isPlatformBrowser, isPlatformServer } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class SeoService {

  private renderer: Renderer2;

  constructor(
    private sanitizer: DomSanitizer,
    private title: Title,
    private meta: Meta,
    @Inject(DOCUMENT) private doc: any,
    @Inject(PLATFORM_ID) private platformId: any,
    private rendererFactory: RendererFactory2) {

    this.renderer = this.rendererFactory.createRenderer(null, null);

  }

  public addScript(type: string, script: string) {
    //Add script tag
    let scriptTag = this.doc.createElement('script');

    //Set attributes
    scriptTag.setAttribute('type', type);
    scriptTag.innerHTML = script

    //Add script to header
    this.doc.head.appendChild(scriptTag);
  }

  public addScriptUrl(type: string, url: string) {

    let scripts = Array.from(this.doc.head.querySelectorAll('script'))

    let script = scripts.find(x => {
      const scriptElement = x as HTMLScriptElement;
      return scriptElement.src && scriptElement.src.includes(url);
    });

    if (!script) {
      let scriptTag = this.doc.createElement('script');

      //Set attributes
      scriptTag.setAttribute('type', type);
      scriptTag.src = url

      //Add script to header
      this.doc.head.appendChild(scriptTag);
    }

  }

  async updateTitle(ogTitle: string) {
    // const translation = await this.getTranslation(ogTitle);
    this.title.setTitle(ogTitle)

    this.meta.updateTag({
      name: 'title',
      content: ogTitle
    });
  }

  async updateDescription(ogDesc: string) {
    // const translation = await this.getTranslation(ogDesc);

    this.meta.updateTag({
      name: 'description',
      content: ogDesc
    });
  }


  async updateTitleTwitter(title: string) {
    this.meta.updateTag({
      name: 'twitter:title',
      content: title
    });
  }

  async updateDescriptionTwitter(description: string) {
    this.meta.updateTag({
      name: 'twitter:description',
      content: description
    });
  }

  async updateOgTitleFacebook(title: string) {
    this.meta.updateTag({
      property: 'og:title',
      content: title
    });
  }

  async updateOgDescriptionFacebook(description: string) {
    this.meta.updateTag({
      property: 'og:description',
      content: description
    });
  }


  async updateOgUrlFacebook(url: string) {

    this.meta.updateTag({
      property: 'og:url',
      content: url
    });
  }


  async updateOgImageFacebook(ogImage: string, width: number, height: number) {
   
    const safeUrl = this.sanitizer.bypassSecurityTrustUrl(ogImage);

    // Convierte SafeUrl a string
const safeUrlString = this.sanitizer.sanitize(SecurityContext.URL, safeUrl);

    this.meta.updateTag({
      property: 'og:image',
      content: safeUrlString!
    });

    this.meta.updateTag({
      property: 'og:image:secure_url',
      content: safeUrlString!
    });

  }

  async updateTwitterURL_Site(url: string) {

    this.meta.updateTag({
      name: 'twitter:url',
      content: url
    });

    this.meta.updateTag({
      name: 'twitter:site',
      content: url
    });
  }

  async updateTwitterImage(image: string) {

    image = image.replace(/&amp ;/g, '&');

    this.meta.updateTag({
      name: 'twitter:image',
      content: decodeURI(image)
    });
  }


  async disableFollow() {
    this.meta.addTag({
      name: 'robots',
      property: 'robots',
      content: 'noindex, nofollow'
    });
  }

  async enableFollow() {
    this.meta.removeTag('robots');
  }


  updateCanonicalURL(url: string) {
    let link: HTMLLinkElement = this.doc.querySelector("link[rel='canonical']");

    if (link) {
      link.setAttribute('href', url);
    } else {
      this.setCanonicalURL(url);
    }
  }

  updateAlternateEsURL(url: string) {

    let link = this.doc.querySelector('link[rel="alternate"][hreflang="es"]');

    if (link) {
      link.setAttribute('href', url);
    }
  }

  updateAlternateEnURL(url: string) {


//     let link = this.doc.querySelector('link[rel="alternate"][hreflang="en"]');
// console.log(link)
//     if (link) {
//       link.setAttribute('href', url);
//     }

const selector = `link[rel="alternate"][hreflang="en"]`;
let link: HTMLLinkElement | null = this.doc.querySelector(selector);

    if (link) {
      this.renderer.setAttribute(link, 'href', url);
    } else {
      link = this.renderer.createElement('link');
      this.renderer.setAttribute(link, 'rel', 'alternate');
      this.renderer.setAttribute(link, 'hreflang', "en");
      this.renderer.setAttribute(link, 'href', url);
      this.renderer.appendChild(this.doc.head, link);
    }

    // Forzar actualización del DOM
    this.renderer.setAttribute(this.doc.documentElement, 'lang', this.doc.documentElement.lang);
  }


  setCanonicalURL(url?: string) {
    const canURL = url == undefined ? this.doc.URL : url;
    const link: HTMLLinkElement = this.doc.createElement('link');
    link.setAttribute('rel', 'canonical');
    link.setAttribute('href', canURL);
    this.doc.head.appendChild(link);
  }


  updateHrefLang(langLinks: { lang: string, url: string }[]) {
    const head = document.getElementsByTagName('head')[0];
    // Remove existing hreflang links
    const existingLinks = document.querySelectorAll('link[rel="alternate"]');
    existingLinks.forEach(link => head.removeChild(link));

    // Add new hreflang links
    langLinks.forEach(link => {
      const linkElement = this.renderer.createElement('link');
      this.renderer.setAttribute(linkElement, 'rel', 'alternate');
      this.renderer.setAttribute(linkElement, 'hreflang', link.lang);
      this.renderer.setAttribute(linkElement, 'href', link.url);
      this.renderer.appendChild(head, linkElement);
    });
  }

}