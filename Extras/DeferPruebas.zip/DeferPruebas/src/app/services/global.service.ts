import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  public static version = '0.0.1';
  public static isMobile = false;

  //#region Observables

  private static RecargarMenuSubject = new Subject<void>()

  public static publishRecargarMenu(): void {
    this.RecargarMenuSubject.next()
  }

  public static getRecargarMenuObservable(): Subject<void> {
    return this.RecargarMenuSubject
  }

  //#endregion

  constructor() { 
    // Simplified constructor - no language detection needed
  }

}

