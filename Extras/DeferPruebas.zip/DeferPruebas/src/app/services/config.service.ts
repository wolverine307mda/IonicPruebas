import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  private nombreAplicacion: string;
  private pushPublicKey: string;
  private enviroment = environment

  constructor(private http: HttpClient) {

    this.enviroment = environment;
    this.nombreAplicacion = 'Suma inmobiliaria';

    this.pushPublicKey = "xxx";
  }

  public getPushPublicKey(): string {
    return this.pushPublicKey;
  }

  public getUrlWeb(): string {
    return this.enviroment.urlWeb;
  }

  public getUrlService(): string {
    return this.enviroment.urlApi
  }

  public getNombreAplicacion() {
    return this.nombreAplicacion;
  }

}
