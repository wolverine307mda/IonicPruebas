import { Injectable } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { UtilService } from './util.service';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {

  constructor(
    private router: Router
  ) { }

  reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentUrl]);
    });
  }

  public async goTo(page: string | undefined | null, id?: string | number | null | undefined, queryParams: NavigationExtras = {}) {

    if (UtilService.isLengthGreatThan0(page)) {
      let _id = '';
      if (id != undefined && id != null && id.toString().trim().length > 0) {
        _id = `/${id}`
      }
      // await this.loader.show();
      // this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([`/${page}${_id}`], queryParams)
      // });
    }

  }

  public getUrlBase(urlNavegacion: string): string {
    if (UtilService.isLengthGreatThan0(urlNavegacion)) {
      if (urlNavegacion?.indexOf("?") != -1) {
        let urlBase = urlNavegacion?.split("?")[0]
        return urlBase;
      }
    }
    return <string>urlNavegacion;
  }

  public getQueryParams(urlNavegacion: string): any {
    if (UtilService.isLengthGreatThan0(urlNavegacion)) {
      if (urlNavegacion?.indexOf("?") != -1) {
        let params = new URLSearchParams(urlNavegacion?.substring(urlNavegacion.indexOf("?")))
        let queryParams: any = {}
        params.forEach((value: string, key: string) => {
          queryParams[key] = value
        })
        return queryParams;
      }
    }
    return {};
  }

}
