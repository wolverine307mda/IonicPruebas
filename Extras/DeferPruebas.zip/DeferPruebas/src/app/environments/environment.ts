export const environment = {
  production: false,
  //urlApi: 'https://intranet.sumainmobiliaria.es/apisumaweb',
  urlApi: 'http://localhost:44059/apisumaweb',

  urlWeb: 'http://localhost:4200',
};