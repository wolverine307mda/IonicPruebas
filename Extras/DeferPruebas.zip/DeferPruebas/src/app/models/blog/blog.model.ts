export default class BlogModel{
    public id: number = 0;
    public titulo: string = '';
    public slugURLES: string = '';
    public slugURLEN: string = ''; // Mantenido para compatibilidad
    public subtitulo: string = '';
    public anclado: boolean = false;
    public contenidoHTML: string = '';
    public fechaIns: string = '';
    public imagenCabecera: string = '';
}