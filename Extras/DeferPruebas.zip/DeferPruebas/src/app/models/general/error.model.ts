export default class ErrorClass {

        public Message: string = '';
        public HasError: boolean | undefined;
}
