export default class PagingModel<T> {
        constructor(
            public collection: T[],
            public count: number,
            public total: number
        ) { }
    }

