import { Component, Input, OnInit, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import BlogModel from '../../models/blog/blog.model';
import { NavigationService } from '../../services/navigation.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { SkeletonModule, Skeleton } from 'primeng/skeleton';
import { NgxSkeletonLoaderComponent } from "ngx-skeleton-loader";
import { SkeletonListBlog } from "../skeleton-list-blog/skeleton-list-blog";

@Component({
  selector: 'app-caja-blog-listado',
  standalone: true,
  imports: [CommonModule, RouterModule, LazyLoadImageModule, NgxSkeletonLoaderComponent, SkeletonListBlog],
  templateUrl: './caja-blog-listado.component.html',
  styleUrls: ['./caja-blog-listado.component.scss']
})
export class CajaBlogListadoComponent implements OnChanges {
  @Input() dataBlog!: BlogModel;
  @Input() mostrarLoader: boolean = false;

  imagenCargada = false;

  ngOnChanges() {
    this.imagenCargada = false;
  }

  onImagenCargada() {
    this.imagenCargada = true;
  }

  onImagenError() {
    console.error('Error al cargar la imagen');
  }

  constructor(private navigationService: NavigationService) {}

  irDetalle(dataBlog: BlogModel) {
    if (dataBlog && dataBlog.id > 0) {
      this.navigationService.goTo(
        'blog/',
        dataBlog.titulo.trim().toLowerCase().replace(/\s+/g, '-')
      );
    }
  }
}
