import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-spinner',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="spinner" [ngStyle]="{ 'width.px': size, 'height.px': size }"></div>
`,
styles: [`
  .spinner {
    border: 4px solid rgba(18, 71, 186, 0.1);
    border-left-color: #1348BA;
    border-radius: 50%;
    width: 40px; /* Tamaño predeterminado */
    height: 40px; /* Tamaño predeterminado */
    animation: spin 1s linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`]
})
export class SpinnerComponent {
  @Input() size: number = 40; // Tamaño predeterminado del spinner
}
