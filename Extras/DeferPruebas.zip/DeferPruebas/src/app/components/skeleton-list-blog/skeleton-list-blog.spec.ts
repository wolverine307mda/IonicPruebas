import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SkeletonListBlog } from './skeleton-list-blog';

describe('SkeletonListBlog', () => {
  let component: SkeletonListBlog;
  let fixture: ComponentFixture<SkeletonListBlog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SkeletonListBlog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SkeletonListBlog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
