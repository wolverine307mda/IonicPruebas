import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSkeletonLoaderComponent } from "ngx-skeleton-loader";

@Component({
  selector: 'app-skeleton-list-blog',
  imports: [CommonModule, NgxSkeletonLoaderComponent],
  templateUrl: './skeleton-list-blog.html',
  styleUrl: './skeleton-list-blog.scss'
})
export class SkeletonListBlog {
}
