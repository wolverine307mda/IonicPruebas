import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

@Component({
  selector: 'app-busqueda',
  standalone: true,
  imports: [ReactiveFormsModule],  
  templateUrl: './busqueda.html',
  styleUrl: './busqueda.scss'
})
export class Busqueda implements OnInit{

  @Input() placeholder: string = '';
  @Output() busqueda = new EventEmitter<string>();
  
  busqueda_control = new FormControl('');
  
  ngOnInit(): void {
      this.busqueda_control.valueChanges.pipe(
          filter(valor => valor?.length === 0 || valor!.length >= 2), 
          debounceTime(700),   // hacemos una pausa de 700 ms
          distinctUntilChanged(),       //comprobamos si el valor ha cambiado
        )
    .subscribe(valor => this.busqueda.emit(valor ? valor : ''));  // emitimos el valor al componente padre
  }

}
