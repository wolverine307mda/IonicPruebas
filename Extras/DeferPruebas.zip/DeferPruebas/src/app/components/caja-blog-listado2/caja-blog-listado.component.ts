import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import BlogModel from '../../models/blog/blog.model';
import { NavigationService } from '../../services/navigation.service';
import { LazyLoadImageModule } from 'ng-lazyload-image';
import { NgxSkeletonLoaderComponent } from "ngx-skeleton-loader";
import { SpinnerComponent } from "../spinner/spinner.component";

@Component({
  selector: 'app-caja-blog-listado2',
  standalone: true,
  templateUrl: './caja-blog-listado.component.html',
  styleUrls: ['./caja-blog-listado.component.scss'],
  imports: [CommonModule, RouterModule, LazyLoadImageModule, NgxSkeletonLoaderComponent, SpinnerComponent]
})
export class CajaBlogListadoComponent2 {

  @Input() dataBlog!: BlogModel;
  @Input() mostrarLoader: boolean = false;
  
  public languageService = { language: 'es' };

  constructor(
    private navigationService: NavigationService
  ){
  }


  irDetalle(dataBlog : BlogModel){

    if (dataBlog != null && dataBlog != undefined && dataBlog.id > 0){
      this.navigationService.goTo('blog/', dataBlog.titulo.trim().toLowerCase().replace(/\s+/g, '-'))
    }


  }

}
