import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiService } from '../api-service';
import BlogModel from '../../models/blog/blog.model';
import PagingModel from '../../models/general/paging.model';
import { Location } from '@angular/common';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class BlogService {

    public api!: ApiService;

    constructor(
        public http: HttpClient,
        private location: Location
    ) {
    }

    public async getBlogs(start: number = 0, limit: number = 21): Promise<BlogModel[]> {
        // console.log('URL de la API:', this.api.url);
        
          const params = {
                idioma: 'es',
                start,
                limit,
            };
        
        try {
            const result = await this.api.HttpGet<any>('/blog/getListadoBlogs', params);
            
            // La API devuelve { collection: BlogModel[] }
            if (result && result.collection && Array.isArray(result.collection)) {
                return result.collection as BlogModel[];
            } else {
                return [];
            }
        } catch (error) {
            console.error('BlogService: Error en la petición:', error);
            throw error;
        }
    }

    public async getBlogsFiltrado(start: number = 0, limit: number = 21, filtro_Busqueda: string): Promise<BlogModel[]> {

          const params = {
                idioma: 'es',
                start,
                limit,
                filtro_Busqueda,
            };
        
        try {
            const result = await this.api.HttpGet<any>('/blog/getBlogsFiltrado', params);
            
            if (result && result.collection && Array.isArray(result.collection)) {
                return result.collection as BlogModel[];
            } else {
                return [];
            }
        } catch (error) {
            console.error('BlogService: Error en la petición:', error);
            throw error;
        }
    }

    public async getBlogsWithPagination(start: number = 0, limit: number = 21): Promise<PagingModel<BlogModel>> {
        
          const params = {
                idioma: 'es',
                start,
                limit,
            };
        
        try {
            const result = await this.api.HttpGet<any>('/blog/getListadoBlogs', params);
            
            // La API devuelve { collection: BlogModel[], total: number }
            if (result && result.collection && Array.isArray(result.collection)) {
                const total = result.total || 50; // Usar 50 como fallback para testing
                return new PagingModel(result.collection as BlogModel[], result.collection.length, total);
            } else {
                return new PagingModel([], 0, 0);
            }
        } catch (error) {
            console.error('BlogService: Error en la petición:', error);
            throw error;
        }
    }

    public async getUltimasEntradas(
        id: ItemBlogNumber
    ): Promise<BlogModel[]> {
        return await this.api.HttpPost('/blog/getUltimasEntradas', id)
    }

    public async getBlogById(blogId: string): Promise<BlogModel> {
        return await this.api.HttpGet('/blog/getBlogById', {
            blogId: blogId,
            idioma: 'es'
        })
    }

    public async getByTitulo(titulo: string): Promise<BlogModel> {
        return await this.api.HttpGet('/blog/getByTitulo', {
            tituloFormat: titulo,
            idioma: 'es'
        })
    }

}


export default class ItemBlogNumber {
    public id: number = 0;
}