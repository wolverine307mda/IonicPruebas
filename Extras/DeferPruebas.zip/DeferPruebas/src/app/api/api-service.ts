import { Injectable } from '@angular/core';
import { HttpHandler, HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { BlogService } from './blog/blog.service';
import { BehaviorSubject, Observable, OperatorFunction, defer, firstValueFrom, map, retry, throwError } from 'rxjs';
import { ConfigService } from '../services/config.service';
import ResultClass from '../models/general/result.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  public url: string | null;
  public urlSEO: string | null;
  public logged!: boolean;
  public nombrePropietario: string | null = null;
  public propietarioLogged: boolean = false;

  public nombreCompletoPropietario = new BehaviorSubject<string>("");
  public propietarioId = new BehaviorSubject<number>(0);


  constructor(
    public config: ConfigService,
    public http: HttpClient,
    public httpHandler: HttpHandler,
    public sanitize: DomSanitizer,
    public Blogs: BlogService,
  ) {
    this.url = config.getUrlService();
    this.urlSEO = config.getUrlWeb();
    this.Blogs.api = this;
  }


  //#region Configuración de la petición

  private ConfigureHeaders(contentType?: string): HttpHeaders {
    if (contentType == null) contentType = 'application/json'
    let headers = new HttpHeaders()
    if (contentType as any !== false) {
      headers = headers.append('Content-Type', contentType)
    }
    return headers
  }

  private ConfigureParams(params: any): HttpParams {
    params = params || {}
    let httpParams = new HttpParams()
    for (let param in params) {
      if (params[param] != null) {
        httpParams = httpParams.append(param, params[param]?.toString() || '')
      } else {
        httpParams = httpParams.append(param, '')
      }
    }
    return httpParams
  }

  //#endregion


  //#region Pipes

  public ResultClassPipe<T>(): OperatorFunction<any, any> {
    return map((result: ResultClass<T>) => {
      if (result.Error && result.Error.HasError) {
        throw new Error(result.Error.Message)
      }
      return result.content
    })
  }

  public HandleHttpErrorPipe<T>(useResultClass: boolean): OperatorFunction<any, any> {
    if (useResultClass == null) useResultClass = true
    return retry({
      delay: (error, retryCount) => {
        if (retryCount < 2) {
        }
        if (useResultClass) {
          let result: ResultClass<T> = error?.error
          if (result?.Error?.Message != null) {
            return throwError(() => new Error(result?.Error?.Message || 'Error desconocido.'))
          }
        }
        return throwError(() => error)
      }
    })
  }

  public HandleResultClassErrorSimple<T>(): OperatorFunction<any, any> {
    return retry({
      delay: (error) => {
        let result: ResultClass<T> = error?.error || 'Error desconocido.'
        if (result?.Error?.Message != null) {
          return throwError(() => new Error(result?.Error?.Message || 'Error desconocido.'))
        } else {
          return throwError(() => error)
        }
      }
    })
  }

  //#endregion


  //#region  "Funciones HTTP"

  public HttpGet<T>(url: string, params?: any, useResultClass?: boolean, useReauthenticate?: boolean): Promise<T> {
    let pipes: OperatorFunction<any, any>[] = []
    if (useResultClass == null || useResultClass == true) {
      pipes.push(this.ResultClassPipe<T>())
    }
    if (useReauthenticate == null || useReauthenticate == true) {
      pipes.push(this.HandleHttpErrorPipe<T>(useResultClass!))
    } else if (useResultClass) {
      pipes.push(this.HandleResultClassErrorSimple<T>())
    }
    return firstValueFrom(this.HttpGetObservable(this.url + url, {
      headers: this.ConfigureHeaders(),
      params: this.ConfigureParams(params),
      withCredentials: true
    }).pipe(...pipes as [OperatorFunction<any, any>]))
  }


  public HttpPost<T>(url: string, params?: any, useResultClass?: boolean, useReauthenticate?: boolean): Promise<T> {
    let pipes: OperatorFunction<any, any>[] = []
    if (useResultClass == null || useResultClass == true) {
      pipes.push(this.ResultClassPipe<T>())
    }
    if (useReauthenticate == null || useReauthenticate == true) {
      pipes.push(this.HandleHttpErrorPipe<T>(useResultClass!))
    } else if (useResultClass) {
      pipes.push(this.HandleResultClassErrorSimple<T>())
    }
    params = params || {}
    return firstValueFrom(this.HttpPostObservable(this.url + url, JSON.stringify(params), {
      headers: this.ConfigureHeaders(),
      withCredentials: true
    }).pipe(...pipes as [OperatorFunction<any, any>]))
  }

  public HttpPostFormData<T>(url: string, formData: FormData, useResultClass?: boolean, useReauthenticate?: boolean): Promise<T> {
    let pipes: OperatorFunction<any, any>[] = []
    if (useResultClass == null || useResultClass == true) {
      pipes.push(this.ResultClassPipe<T>())
    }
    if (useReauthenticate == null || useReauthenticate == true) {
      pipes.push(this.HandleHttpErrorPipe<T>(useResultClass!))
    } else if (useResultClass) {
      pipes.push(this.HandleResultClassErrorSimple<T>())
    }
    return firstValueFrom(this.HttpPostObservable(this.url + url, formData, {
      headers: this.ConfigureHeaders(false as any),
      withCredentials: true
    }).pipe(...pipes as [OperatorFunction<any, any>]))
  }

  //#endregion

  //#region Funciones Custom HTTP

  /* Utilizaremos estas funciones para procesar el Token cada vez que se disparan, de esa forma el Retry de HandleHttpErrorPipe intentará la petición con un token nuevo y no
     con el mismo token que se creó el observable original. */

  private HttpGetObservable(url: string, params: {
    headers: HttpHeaders,
    params: HttpParams,
    withCredentials: boolean
  }): Observable<any> {
    return defer(() => {
      return this.http.get(url, {
        headers: params.headers,
        params: params.params,
        withCredentials: params.withCredentials
      })
    })
  }

  private HttpPostObservable(url: string, body: string | FormData, params: {
    headers: HttpHeaders,
    withCredentials: boolean
  }): Observable<any> {
    return defer(() => {
      return this.http.post(url, body, {
        headers: params.headers,
        withCredentials: params.withCredentials
      })
    })
  }

  private HttpPutObservable(url: string, body: string | FormData, params: {
    headers: HttpHeaders,
    withCredentials: boolean
  }): Observable<any> {
    return defer(() => {
      return this.http.put(url, body, {
        headers: params.headers,
        withCredentials: params.withCredentials
      })
    })
  }

  private HttpDeleteObservable(url: string, params: {
    headers: HttpHeaders,
    params: HttpParams,
    withCredentials: boolean
  }): Observable<any> {
    return defer(() => {
      return this.http.delete(url, {
        headers: params.headers,
        params: params.params,
        withCredentials: params.withCredentials
      })
    })
  }

  //#endregion


}
